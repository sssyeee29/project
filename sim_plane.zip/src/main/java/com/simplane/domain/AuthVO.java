package com.simplane.domain;

import lombok.Data;

@Data
public class AuthVO {

    private Integer memberid;
    private String auth;
}