package com.simplane.service;

import com.simplane.domain.TestVO;

import java.util.List;

public interface TestService {

    List<TestVO> getAllTests();
}