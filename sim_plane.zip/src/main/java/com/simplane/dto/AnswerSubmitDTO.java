package com.simplane.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class AnswerSubmitDTO {
    private Long answerid;
}